#!/usr/bin/env bash
set -euo pipefail

# Run from the root of aluctracrt-ai/-DSiCast-test after extracting this pack.
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"

mkdir -p dsicast-exp tools .github/workflows
cp -f "$HERE"/dsicast-exp/* dsicast-exp/
cp -f "$HERE"/tools/patch_ndsbootstrap.py tools/patch_ndsbootstrap.py
cp -f "$HERE"/.github/workflows/dsicast-build.yml .github/workflows/dsicast-build.yml
chmod +x dsicast-exp/build_workers.sh tools/patch_ndsbootstrap.py

git add dsicast-exp tools/patch_ndsbootstrap.py .github/workflows/dsicast-build.yml
if git diff --cached --quiet; then
  echo 'DSiCast experiment files are already installed.'
else
  git commit -m 'Build DSiCast in-game unlimited experimental stream'
  git push
fi

echo
echo 'Done. Open GitHub -> Actions -> DSiCast In-Game Unlimited EXPERIMENTAL.'

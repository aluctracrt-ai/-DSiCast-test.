DSiCast - tentative IN-GAME UNLIMITED
=====================================

CE PACK EST EXPERIMENTAL.
Il vise directement ce test :
Mario Kart DS -> L+R+SELECT -> flux continu vers DSiCast Receiver.

FPS :
AUCUNE limite logicielle de FPS n'est configuree.
Le preferred_fps envoye par le Receiver est volontairement ignore.
Une nouvelle capture est demandee des que la frame precedente a quitte la file UDP.
Le debit reel sera donc uniquement limite par la DSi, Display Capture et le Wi-Fi.
Le maximum de frames uniques reste physiquement lie au rafraichissement de la DS (~60 Hz).

Pour donner plus de chances au PREMIER test reseau, la video envoyee est 128x96 RGB555.
Ce n'est PAS une limite de FPS. Si la chaine fonctionne, la resolution/delta seront la suite.

INSTALLATION DANS TON CODESPACE
1. Uploade le ZIP dans la racine de ton repo.
2. Dans le terminal, depuis /workspaces/-DSiCast-test. :

   unzip -o DSiCast-InGame-Unlimited-Experiment.zip -d DSiCast-InGame-Unlimited-Experiment
   bash DSiCast-InGame-Unlimited-Experiment/install.sh

3. Va dans GitHub -> Actions -> DSiCast In-Game Unlimited EXPERIMENTAL.
4. Si c'est vert, telecharge l'artifact DSiCast-InGame-Unlimited-EXPERIMENTAL.
5. Lis READ-ME-FIRST.txt avant de remplacer ton nightly.

Si l'Action est rouge, ne recommence pas au hasard : envoie la partie rouge/log ici.
